INT161 ชุดสอบปฏิบัติ

TEMPLATE_DONE/      โค้ดสำเร็จรูป ชื่อไฟล์ตรงกับ midterm-exam-esm-template ทุกตัว
                    copy src/ ไปทับ template → Replace in Files  -$id → -รหัสเรา → แก้บรรทัดที่มี ←
                    บรรทัดที่แก้จาก template มี comment "แก้:"
                    ทดสอบแล้ว: test-runner อาจารย์ 100/100 (DB mobile_distributor)

INT161_DOCS.html    แนวข้อสอบ W8: โจทย์ → วิธีทำ → โค้ด ทีละข้อ
                    โค้ดทุกกรณี C R U D + syntax
                    Ctrl+K  ค้นหาทั้งไฟล์ (ไทย/อังกฤษ, พิมพ์ผิดได้, r: 404, sql: join)
